package com.zoho.security.sca.androidDexer;

/**
 * A class that numbers objects, so they can be placed in bitsets.
 *
 */

public interface Numberable {
  public void setNumber(int number);

  public int getNumber();
}