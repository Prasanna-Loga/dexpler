package com.zoho.security.sca.androidDexer;

import java.io.File;
import java.io.IOException;

import org.jf.dexlib2.DexFileFactory;
import org.jf.dexlib2.Opcodes;

import org.jf.dexlib2.iface.ClassDef;
import org.jf.dexlib2.iface.DexFile;
import org.jf.util.StringUtils;

import com.zoho.security.androidDexer.adapter.ClassDefinition;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		long startTime = System.currentTimeMillis();
		
		String file="/home/local/ZOHOCORP/prasanna-8769/Downloads/app-debug/classes.dex";
		
		
		//int jobs = Runtime.getRuntime().availableProcessors();
		
		Options option=new Options();
		
		
		DexFile dexFile;
		
		System.out.println(Opcodes.getDefault());
		
		dexFile = DexFileFactory.loadDexFile(new File(file), Opcodes.getDefault());
		
		System.out.println(file);
		
		for (ClassDef classDef : dexFile.getClasses()) {
			
			System.out.println();
			
			ClassDefinition classDefinition=new ClassDefinition(option, classDef);
			classDefinition.displayModel();
		}
		
		
		
		
//		DexInput dexinput = new DexInput();
//		dexinput.disassembleDexFile(dexFile,jobs,option);
		
		Runtime runtime = Runtime.getRuntime();
		// Run the garbage collector
		runtime.gc();
		// Calculate the used memory
		long memory = runtime.totalMemory() - runtime.freeMemory();
		System.out.println("Used memory is bytes: " + memory / (1024L * 1024L) + "mb");

		 

		long stopTime = System.currentTimeMillis();
		long elapsedTime = stopTime - startTime;
		System.out.println("Time: " + elapsedTime + "ms");
		
		
	}

}
