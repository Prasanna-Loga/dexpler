package com.zoho.security.sca.androidDexer;

public class InvalidDalvikBytecodeException extends RuntimeException {

	  /**
	   * 
	   */
	  private static final long serialVersionUID = -1932386032493767303L;

	  public InvalidDalvikBytecodeException(String msg) {
	    super(msg);
	  }

	}