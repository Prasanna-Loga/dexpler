package com.zoho.security.androidDexer.adapter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Nonnull;

import org.jf.dexlib2.AccessFlags;
import org.jf.dexlib2.iface.Annotation;
import org.jf.dexlib2.iface.Method;
import org.jf.dexlib2.iface.MethodImplementation;
import org.jf.dexlib2.iface.MethodParameter;
import org.jf.dexlib2.iface.debug.DebugItem;
import org.jf.dexlib2.iface.instruction.Instruction;
import org.jf.dexlib2.immutable.debug.ImmutableLineNumber;
import org.jf.dexlib2.util.MethodUtil;
import org.jf.dexlib2.util.TypeUtils;
import com.google.common.collect.ImmutableList;
import com.zoho.security.andriodDexer.Instruction.CheckCastInstruction;
import com.zoho.security.andriodDexer.Instruction.ConditionalJumpInstruction;
import com.zoho.security.andriodDexer.Instruction.ConstInstruction;
import com.zoho.security.andriodDexer.Instruction.ConstStringInstruction;
import com.zoho.security.andriodDexer.Instruction.DexlibAbstractInstruction;
import com.zoho.security.andriodDexer.Instruction.InstructionFactory;
import com.zoho.security.andriodDexer.Instruction.JumpInstruction;
import com.zoho.security.andriodDexer.Instruction.MethodInvocationInstruction;
import com.zoho.security.andriodDexer.Instruction.MoveInstruction;
import com.zoho.security.andriodDexer.Instruction.MoveResultInstruction;
import com.zoho.security.andriodDexer.Instruction.RegisterFormatter;
import com.zoho.security.andriodDexer.Instruction.ReturnInstruction;
import com.zoho.security.andriodDexer.Instruction.TaggedInstruction;
import com.zoho.security.sca.androidDexer.InvalidDalvikBytecodeException;
import com.zoho.security.sca.androidDexer.Local;
import com.zoho.security.sca.androidDexer.Options;


public class MethodDefinition {
	
	@Nonnull public static ClassDefinition classDef;
    @Nonnull public static Method method;
    @Nonnull public static MethodImplementation methodImpl;
	private static ArrayList<DexlibAbstractInstruction> instructions;
//    @Nonnull public final ImmutableList<Instruction> instructions;
//    @Nonnull public static List<Instruction> effectiveInstructions;
//
//    @Nonnull public static ImmutableList<MethodParameter> methodParameters;
	protected static HashMap<Integer, DexlibAbstractInstruction> instructionAtAddress;
	protected int numRegisters;
	protected static Local[] registerLocals;
	protected static Local[] registerParameters;
	protected static Local storeResultLocal;
	public static RegisterFormatter registerFormatter;

    //@Nonnull private final LabelCache labelCache = new LabelCache();

//    @Nonnull private final SparseIntArray packedSwitchMap;
//    @Nonnull private final SparseIntArray sparseSwitchMap;
//    @Nonnull private final InstructionOffsetMap instructionOffsetMap;

    public MethodDefinition(@Nonnull ClassDefinition classDef, @Nonnull Method method,
                            @Nonnull MethodImplementation methodImpl) {
        this.classDef = classDef;
        this.method = method;
        this.methodImpl = methodImpl;
        
        instructions = new ArrayList<DexlibAbstractInstruction>();
        instructionAtAddress = new HashMap<Integer, DexlibAbstractInstruction>();
        
       
        

//        try {
//            
//            instructions = ImmutableList.copyOf(methodImpl.getInstructions());
//            methodParameters = ImmutableList.copyOf(method.getParameters());

//            effectiveInstructions = Lists.newArrayList(instructions);
//
//            packedSwitchMap = new SparseIntArray(0);
//            sparseSwitchMap = new SparseIntArray(0);
//            instructionOffsetMap = new InstructionOffsetMap(instructions);
//
//            int endOffset = instructionOffsetMap.getInstructionCodeOffset(instructions.size()-1) +
//                    instructions.get(instructions.size()-1).getCodeUnits();
//
//            for (int i=0; i<instructions.size(); i++) {
//                Instruction instruction = instructions.get(i);
//
//                Opcode opcode = instruction.getOpcode();
//                if (opcode == Opcode.PACKED_SWITCH) {
//                    boolean valid = true;
//                    int codeOffset = instructionOffsetMap.getInstructionCodeOffset(i);
//                    int targetOffset = codeOffset + ((OffsetInstruction)instruction).getCodeOffset();
//                    try {
//                        targetOffset = findPayloadOffset(targetOffset, Opcode.PACKED_SWITCH_PAYLOAD);
//                    } catch (InvalidSwitchPayload ex) {
//                        valid = false;
//                    }
//                    if (valid) {
//                        if (packedSwitchMap.get(targetOffset, -1) != -1) {
//                            Instruction payloadInstruction =
//                                    findSwitchPayload(targetOffset, Opcode.PACKED_SWITCH_PAYLOAD);
//                            targetOffset = endOffset;
//                            effectiveInstructions.set(i, new ImmutableInstruction31t(opcode,
//                                    ((Instruction31t)instruction).getRegisterA(), targetOffset-codeOffset));
//                            effectiveInstructions.add(payloadInstruction);
//                            endOffset += payloadInstruction.getCodeUnits();
//                        }
//                        packedSwitchMap.append(targetOffset, codeOffset);
//                    }
//                } else if (opcode == Opcode.SPARSE_SWITCH) {
//                    boolean valid = true;
//                    int codeOffset = instructionOffsetMap.getInstructionCodeOffset(i);
//                    int targetOffset = codeOffset + ((OffsetInstruction)instruction).getCodeOffset();
//                    try {
//                        targetOffset = findPayloadOffset(targetOffset, Opcode.SPARSE_SWITCH_PAYLOAD);
//                    } catch (InvalidSwitchPayload ex) {
//                        valid = false;
//                        // The offset to the payload instruction was invalid. Nothing to do, except that we won't
//                        // add this instruction to the map.
//                    }
//                    if (valid) {
//                        if (sparseSwitchMap.get(targetOffset, -1) != -1) {
//                            Instruction payloadInstruction =
//                                    findSwitchPayload(targetOffset, Opcode.SPARSE_SWITCH_PAYLOAD);
//                            targetOffset = endOffset;
//                            effectiveInstructions.set(i, new ImmutableInstruction31t(opcode,
//                                    ((Instruction31t)instruction).getRegisterA(), targetOffset-codeOffset));
//                            effectiveInstructions.add(payloadInstruction);
//                            endOffset += payloadInstruction.getCodeUnits();
//                        }
//                        sparseSwitchMap.append(targetOffset, codeOffset);
//                    }
//                }
//            }
//        } catch (Exception ex) {
//            String methodString;
//            try {
//                methodString = ReferenceUtil.getMethodDescriptor(method);
//            } catch (Exception ex2) {
//                throw ExceptionWithContext.withContext(ex, "Error while processing method");
//            }
//            throw ExceptionWithContext.withContext(ex, "Error while processing method %s", methodString);
//        }
    }

    public static Local[] getRegisterLocals() {
        return registerLocals;
      }

      /**
       * Return the Local that are associated with the number in the current register state.
       *
       * Handles if the register number actually points to a method parameter.
       *
       * @param num
       *          the register number
       * @throws InvalidDalvikBytecodeException
       */
      public static Local getRegisterLocal(int num) throws InvalidDalvikBytecodeException {
        int totalRegisters = registerLocals.length;
        if (num > totalRegisters) {
          throw new InvalidDalvikBytecodeException(
              "Trying to access register " + num + " but only " + totalRegisters + " is/are available.");
        }
        
        return registerLocals[num];
		
      }

      public static Local getStoreResultLocal() {
        return storeResultLocal;
      }

	
	public DexlibAbstractInstruction instructionAtAddress(int address) {
    DexlibAbstractInstruction i = null;
    while (i == null && address >= 0) {
            i = instructionAtAddress.get(address);
      address--;
    }
    return i;
  }


	public static void displayEmptyMethod(Method method,Options options){
		
		QualifiedName qualifiedName=new QualifiedName();
		
		System.out.print("\t");
		displayAccessFlag(method.getAccessFlags());
		
		System.out.print(qualifiedName.getQualifiedName(method.getReturnType())+" ");
		
		System.out.print(qualifiedName.getQualifiedName(method.getName()+"("));
		
		ImmutableList<MethodParameter> methodParameters = ImmutableList.copyOf(method.getParameters());
        
		
		int size=0;
		for (MethodParameter parameter: methodParameters) {
        	size++;
			System.out.print(qualifiedName.getQualifiedName(parameter.toString()));
			if(size!=methodParameters.size())
				System.out.print(", ");
		}
		
		System.out.print(")");
		
		System.out.println(";");
	}

	
	public static void displayMethod() {

		int parameterRegisterCount = 0;
		QualifiedName qualifiedName=new QualifiedName();
		
		System.out.print("\t");
		displayAccessFlag(method.getAccessFlags());
		
		System.out.print(qualifiedName.getQualifiedName(method.getReturnType())+" ");
		
		System.out.print(qualifiedName.getQualifiedName(method.getName()+"("));
		
		parameterRegisterCount=MethodUtil.getParameterRegisterCount(method);
		//if static
		if((method.getAccessFlags()&0x0008)==0)
		parameterRegisterCount--;
		
		registerParameters=new Local[parameterRegisterCount];
		//System.out.println(parameterRegisterCount);
		int size=0;
		parameterRegisterCount=0;
		for (MethodParameter parameter: method.getParameters()) {
			String name=parameter.getName();
            String type = parameter.getType();
            size++;
            if(type!=null)
            System.out.print(qualifiedName.getQualifiedName(type)+" ");
            if(name!=null)
            System.out.print(qualifiedName.getQualifiedName(name));
            if(size!=method.getParameters().size())
            	System.out.print(", ");
            parameterRegisterCount++;
            Local l=new Local();
            l.setName(name);
            l.setType(type);
            registerParameters[parameterRegisterCount-1]=l;
            if (TypeUtils.isWideType(type)) {
                parameterRegisterCount++;
                registerParameters[parameterRegisterCount-1]=l;
            }
        }
		
			System.out.print(") ");
			//System.out.println(methodImpl.getRegisterCount()+" "+parameterRegisterCount);
			//System.out.println(registerFormatter);
			
	        registerFormatter = new RegisterFormatter(classDef.options, methodImpl.getRegisterCount(),parameterRegisterCount);
	        
			
			//System.out.print(parameterRegisterCount	);
			//System.out.print(MethodUtil.getParameterRegisterCount(method));
			
			Collection<? extends Annotation> annotations = method.getAnnotations();
			
			String containingClass = null;
	        if (classDef.options.implicitReferences) {
	            containingClass = method.getDefiningClass();
	        }
				
			AnnotationFormatter.display(annotations, containingClass);
			
			System.out.println("{");
			//Local
			int local=methodImpl.getRegisterCount() - parameterRegisterCount;
			//Register
			int register=methodImpl.getRegisterCount();
			
			 registerLocals = new Local[local];

//			 for(Local l:registerLocals)
//		        System.out.println(l+"************");
//			 for(Local l:registerParameters)
//				 System.out.println(l.getName()+"   "+l.getType());
			
//			List<MethodItem> methodItems = 
					getMethodItems();
//	        for (MethodItem methodItem: methodItems) {
//	        	methodItem.display();
//	        }
			
			
			System.out.println("\n\t}");
	}
	
	private static List<MethodItem> getMethodItems() {
		
		ArrayList<MethodItem> methodItems = new ArrayList<MethodItem>();

        if ((classDef.options.registerInfo != 0) || (classDef.options.normalizeVirtualMethods) ||
                (classDef.options.deodex && needsAnalyzed())) {
            
        	// for odex file
        } else {
        	
        	//only for dex file
        	
            addInstructionMethodItems(methodItems);
        }
		return null;
	}

	private static void addInstructionMethodItems(ArrayList<MethodItem> methodItems) {
		
		int currentCodeAddress = 0;

            for (Instruction instruction : methodImpl.getInstructions()) {
                DexlibAbstractInstruction dexInstruction = InstructionFactory.fromInstruction(instruction, currentCodeAddress);
                instructions.add(dexInstruction);
                instructionAtAddress.put(currentCodeAddress, dexInstruction);
                currentCodeAddress += instruction.getCodeUnits();
              }
            
            
            
            for (DebugItem di : methodImpl.getDebugItems()) {
                if (di instanceof ImmutableLineNumber) {
                  ImmutableLineNumber ln = (ImmutableLineNumber) di;
                  DexlibAbstractInstruction ins = MethodDefinition.instructionAtAddress.get(ln.getCodeAddress());
                  if (ins == null) {
                    // Debug.printDbg("Line number tag pointing to invalid
                    // offset: " + ln.getCodeAddress());
                    continue;
                  }
                  
                  ins.setLineNumber(ln.getLineNumber());
                    }
              }
        usedTypes();
        
        //System.out.println(instructionAtAddress);
	}
	
	
            
            public static void usedTypes() {
            	
                for (DexlibAbstractInstruction i : instructions) {
                	
                	if(i!=null){
                		
                		if(i instanceof MethodInvocationInstruction) 
               			i.display();
                			//System.out.println("----------------"+i.getLineNumber());
                		if(i instanceof ReturnInstruction)
                			i.display();
                		if(i instanceof MoveInstruction)
                			i.display();
                		if(i instanceof MoveResultInstruction)
                			i.display();
                		if(i instanceof ConstInstruction)
                			i.display();
                		if(i instanceof ConstStringInstruction)
                			i.display();
                		if(i instanceof CheckCastInstruction)
                			i.display();
                		if(i instanceof TaggedInstruction)
                			i.display();
                		if(i instanceof JumpInstruction) {
                			//i.getTargetInstruction(method);
                			i.display();
                		}
                	}
                }
	}
            


	private static boolean needsAnalyzed() {
        for (Instruction instruction: methodImpl.getInstructions()) {
            if (instruction.getOpcode().odexOnly()) {
                return true;
            }
        }
        return false;
    }

	private static void displayAccessFlag(int accessFlags) {
		// TODO Auto-generated method stub
		for (AccessFlags accessFlag: AccessFlags.getAccessFlagsForMethod(accessFlags)) {
			System.out.print(accessFlag+" ");
		}
	}

//	 public Instruction findSwitchPayload(int targetOffset, Opcode type) {
//	        int targetIndex;
//	        try {
//	            targetIndex = instructionOffsetMap.getInstructionIndexAtCodeOffset(targetOffset);
//	        } catch (InvalidInstructionOffset ex) {
//	            throw new InvalidSwitchPayload(targetOffset);
//	        }
//
//	        //TODO: does dalvik let you pad with multiple nops?
//	        //TODO: does dalvik let a switch instruction point to a non-payload instruction?
//
//	        Instruction instruction = instructions.get(targetIndex);
//	        if (instruction.getOpcode() != type) {
//	            // maybe it's pointing to a NOP padding instruction. Look at the next instruction
//	            if (instruction.getOpcode() == Opcode.NOP) {
//	                targetIndex += 1;
//	                if (targetIndex < instructions.size()) {
//	                    instruction = instructions.get(targetIndex);
//	                    if (instruction.getOpcode() == type) {
//	                        return instruction;
//	                    }
//	                }
//	            }
//	            throw new InvalidSwitchPayload(targetOffset);
//	        } else {
//	            return instruction;
//	        }
//	    }
//
//	    public int findPayloadOffset(int targetOffset, Opcode type) {
//	        int targetIndex;
//	        try {
//	            targetIndex = instructionOffsetMap.getInstructionIndexAtCodeOffset(targetOffset);
//	        } catch (InvalidInstructionOffset ex) {
//	            throw new InvalidSwitchPayload(targetOffset);
//	        }
//
//	        //TODO: does dalvik let you pad with multiple nops?
//	        //TODO: does dalvik let a switch instruction point to a non-payload instruction?
//
//	        Instruction instruction = instructions.get(targetIndex);
//	        if (instruction.getOpcode() != type) {
//	            // maybe it's pointing to a NOP padding instruction. Look at the next instruction
//	            if (instruction.getOpcode() == Opcode.NOP) {
//	                targetIndex += 1;
//	                if (targetIndex < instructions.size()) {
//	                    instruction = instructions.get(targetIndex);
//	                    if (instruction.getOpcode() == type) {
//	                        return instructionOffsetMap.getInstructionCodeOffset(targetIndex);
//	                    }
//	                }
//	            }
//	            throw new InvalidSwitchPayload(targetOffset);
//	        } else {
//	            return targetOffset;
//	        }
//	    }
//	   
//
//	    public static class InvalidSwitchPayload extends ExceptionWithContext {
//	        private final int payloadOffset;
//
//	        public InvalidSwitchPayload(int payloadOffset) {
//	            super("No switch payload at offset: %d", payloadOffset);
//	            this.payloadOffset = payloadOffset;
//	        }
//
//	        public int getPayloadOffset() {
//	            return payloadOffset;
//	        }
//	    }
}
