package com.zoho.security.androidDexer.adapter;

import java.util.Collection;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.jf.dexlib2.AnnotationVisibility;
import org.jf.dexlib2.iface.Annotation;
import org.jf.dexlib2.iface.AnnotationElement;

import com.zoho.security.androidDexer.EncodedValue.AnnotationEncodedValueAdapter;

public class AnnotationFormatter {
	public static void display(@Nonnull Collection<? extends Annotation> annotations, @Nullable String containingClass) {
		for (Annotation annotation : annotations) {
			//annotation visibility like System,runtime
			AnnotationVisibility.getVisibility(annotation.getVisibility());
			
			Boolean throwFlag=false;
			
			if(annotation.getType().endsWith("Throws;")) {
				if(throwFlag==false) {
					System.out.print("throws ");
					throwFlag=true;
				}
			
			AnnotationEncodedValueAdapter.displayElementsTo(annotation.getElements(), containingClass);

			}
		}
	}

}
