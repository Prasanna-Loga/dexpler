package com.zoho.security.androidDexer.adapter;

public class QualifiedName {
	
	private String qname;
	public String getQualifiedName(String name) {
		qname=name;
		if(qname.charAt(0)=='L'&&qname.charAt(qname.length()-1)==';') {
			qname=qname.substring(1, qname.length()-1);
		}
			return qname;
	}

}
