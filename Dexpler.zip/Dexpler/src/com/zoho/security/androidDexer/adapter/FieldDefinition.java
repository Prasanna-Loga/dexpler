package com.zoho.security.androidDexer.adapter;

import org.jf.dexlib2.AccessFlags;
import org.jf.dexlib2.iface.Field;
import org.jf.dexlib2.iface.value.EncodedValue;
import org.jf.dexlib2.util.EncodedValueUtils;

import com.zoho.security.androidDexer.EncodedValue.EncodedValueAdaptor;
import com.zoho.security.sca.androidDexer.Options;

public class FieldDefinition {

	public static void display(Options options, Field field, boolean setInStaticConstructor) {
		
		EncodedValue initialValue = field.getInitialValue();
		int accessFlags=field.getAccessFlags();
		
		if (setInStaticConstructor &&
                AccessFlags.STATIC.isSet(accessFlags) &&
                AccessFlags.FINAL.isSet(accessFlags) &&
                initialValue != null) {
            if (!EncodedValueUtils.isDefaultValue(initialValue)) {
                // The value of this static final field might be set in the static constructor
            } else {
                // don't write out the default initial value for static final fields that get set in the static
                // constructor
                initialValue = null;
            }
        }
		
		QualifiedName qualifiedName=new QualifiedName();
		
		System.out.print("\t");
		displayAccessFlag(accessFlags);
		
		System.out.print(qualifiedName.getQualifiedName(field.getType())+" ");
		System.out.print(qualifiedName.getQualifiedName(field.getName())+" ");
		
		if(initialValue!=null) {
			System.out.print("= ");
			String containingClass = null;
            if (options.implicitReferences) {
                containingClass = field.getDefiningClass();
            }

            EncodedValueAdaptor.display(initialValue, containingClass);
        
		}
		System.out.println();
	}

	private static void displayAccessFlag(int accessFlags) {
		
		for (AccessFlags accessFlag: AccessFlags.getAccessFlagsForField(accessFlags)) {
			System.out.print(accessFlag+" ");
		}
	          
	}

}
