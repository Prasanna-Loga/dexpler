package com.zoho.security.androidDexer.adapter;

import org.jf.dexlib2.AccessFlags;
import org.jf.dexlib2.dexbacked.DexBackedClassDef;
import org.jf.dexlib2.iface.*;
import org.jf.dexlib2.iface.instruction.Instruction;
import org.jf.dexlib2.iface.instruction.formats.Instruction21c;
import org.jf.dexlib2.iface.reference.FieldReference;
import org.jf.dexlib2.util.ReferenceUtil;

import com.zoho.security.sca.androidDexer.Options;

import javax.annotation.Nonnull;
import java.util.*;


public class ClassDefinition {
	@Nonnull public final Options options;
    @Nonnull public final ClassDef classDef;
    @Nonnull private final HashSet<String> fieldsSetInStaticConstructor;

    protected boolean validationErrors;

    public ClassDefinition(@Nonnull Options options, @Nonnull ClassDef classDef) {
        this.options = options;
        this.classDef = classDef;
        fieldsSetInStaticConstructor = findFieldsSetInStaticConstructor(classDef);
    }

    public boolean hadValidationErrors() {
        return validationErrors;
    }

    @Nonnull
    private static HashSet<String> findFieldsSetInStaticConstructor(@Nonnull ClassDef classDef) {
        HashSet<String> fieldsSetInStaticConstructor = new HashSet<String>();

        for (Method method: classDef.getDirectMethods()) {
            if (method.getName().equals("<clinit>")) {
                MethodImplementation impl = method.getImplementation();
                if (impl != null) {
                    for (Instruction instruction: impl.getInstructions()) {
                        switch (instruction.getOpcode()) {
                            case SPUT:
                            case SPUT_BOOLEAN:
                            case SPUT_BYTE:
                            case SPUT_CHAR:
                            case SPUT_OBJECT:
                            case SPUT_SHORT:
                            case SPUT_WIDE: {
                                Instruction21c ins = (Instruction21c)instruction;
                                FieldReference fieldRef = null;
                               // try {
                                    fieldRef = (FieldReference)ins.getReference();
                                //} catch (InvalidItemIndex ex) {
                                    // just ignore it for now. We'll deal with it later, when processing the instructions
                                    // themselves
                                //}
                                if (fieldRef != null &&
                                        fieldRef.getDefiningClass().equals((classDef.getType()))) {
                                    fieldsSetInStaticConstructor.add(ReferenceUtil.getShortFieldDescriptor(fieldRef));
                                }
                                break;
                            }
                        }
                    }
                }
            }
        }
        return fieldsSetInStaticConstructor;
    }

    public void displayModel() {
    	QualifiedName qualifiedname=new QualifiedName();
//    	if(qualifiedname.getQualifiedName(classDef.getType()).equals("kotlin/UByte")) {
    	displayClass();
    	
    	System.out.println(" {");
    	
    	System.out.println();
    	
    	Set<String> staticFields = displayStaicField();
    	
    	displayInstanceField(staticFields);
    	
    	Set<String> directMethods = displayDirectMethod();
    	
    	displayVirtualMethod(directMethods);
    	System.out.println("\n}");
//    	}
    	
    }
    

	private void displayClass() {
    	
    	QualifiedName qualifiedname=new QualifiedName();
    	
    	System.out.print("class ");
    	accessFlag();
    	
    	System.out.print(qualifiedname.getQualifiedName(classDef.getType()));
    	
    	if(classDef.getSuperclass()!=null)
    		System.out.print(" extends "+qualifiedname.getQualifiedName(classDef.getSuperclass()));
    	
    	if(classDef.getInterfaces().size()>0) {
    		List<String> interfaces = classDef.getInterfaces();
    		
    		System.out.print(" implements ");
    		int size=0;
    		for(String interfaceName : interfaces) {
    			size++;
    			System.out.print(qualifiedname.getQualifiedName(interfaceName));
    			if(size!=interfaces.size())
    				System.out.print(", ");
    		}
    	}
    		
    	
    }
	
	private void accessFlag() {
		
		for (AccessFlags accessFlag: AccessFlags.getAccessFlagsForClass(classDef.getAccessFlags())) {
            System.out.print(accessFlag.toString()+" ");
    	}
	}

	private Set<String> displayStaicField() {
		
		Set<String> writtenFields = new HashSet<String>();
		
		Iterable<? extends Field> staticFields;
        if (classDef instanceof DexBackedClassDef) {
            staticFields = ((DexBackedClassDef)classDef).getStaticFields(false);
        } else {
            staticFields = classDef.getStaticFields();
        }

        for (Field field: staticFields) {
        	boolean setInStaticConstructor;
            
            String fieldString = ReferenceUtil.getShortFieldDescriptor(field);
            if (!writtenFields.add(fieldString)) {
               // duplicate field ignored
            	
                System.err.println(String.format("Ignoring duplicate field: %s->%s", classDef.getType(), fieldString));
                setInStaticConstructor = false;
            } else {
                setInStaticConstructor = fieldsSetInStaticConstructor.contains(fieldString);
            }
            FieldDefinition.display(options, field, setInStaticConstructor);
        }
		return writtenFields;
	}
	
	private void displayInstanceField(Set<String> staticFields) {
		


		Set<String> writtenFields = new HashSet<String>();
		
		Iterable<? extends Field> instanceFields;
        if (classDef instanceof DexBackedClassDef) {
        	instanceFields = ((DexBackedClassDef)classDef).getInstanceFields(false);
        } else {
        	instanceFields = classDef.getInstanceFields();
        }

        for (Field field: instanceFields) {
        	boolean setInStaticConstructor;
            
            String fieldString = ReferenceUtil.getShortFieldDescriptor(field);
            if (!writtenFields.add(fieldString)) {
               // duplicate field ignored
            	
                System.err.println(String.format("Ignoring duplicate field: %s->%s", classDef.getType(), fieldString));
                setInStaticConstructor = false;
            } else if(staticFields.contains(fieldString)){
            	 System.err.println(String.format("Duplicate static+instance field found: %s->%s",
                         classDef.getType(), fieldString));
                 System.err.println("You will need to rename one of these fields, including all references.");

            }
            FieldDefinition.display(options, field, false);
        }
		
	}
	
	private Set<String> displayDirectMethod() {
		
		Set<String> writtenMethods = new HashSet<String>();

        Iterable<? extends Method> directMethods;
        if (classDef instanceof DexBackedClassDef) {
            directMethods = ((DexBackedClassDef)classDef).getDirectMethods(false);
        } else {
            directMethods = classDef.getDirectMethods();
        }
        
        for (Method method: directMethods) {
        
        	// TODO: check for method validation errors
            String methodString = ReferenceUtil.getMethodDescriptor(method, true);

            if (!writtenMethods.add(methodString)) {
                // duplicate method ignored
            	System.err.println(String.format("Ignoring duplicate method: %s->%s", classDef.getType(), methodString));
                
            }

            MethodImplementation methodImpl = method.getImplementation();
            if (methodImpl == null) {
            	
            	MethodDefinition.displayEmptyMethod(method, options);
               
            } else {
            	
            	MethodDefinition methodDefinition=new MethodDefinition(this, method, methodImpl);
                methodDefinition.displayMethod();
            }
        	
        }
        return writtenMethods;
		
	}
	
	private void displayVirtualMethod(Set<String> directMethods) {
		
		Set<String> writtenMethods = new HashSet<String>();

        Iterable<? extends Method> virtualMethods;
        if (classDef instanceof DexBackedClassDef) {
            virtualMethods = ((DexBackedClassDef)classDef).getVirtualMethods(false);
        } else {
            virtualMethods = classDef.getVirtualMethods();
        }

        for (Method method: virtualMethods) {

            // TODO: check for method validation errors
            String methodString = ReferenceUtil.getMethodDescriptor(method, true);

            if (!writtenMethods.add(methodString)) {
                // duplicate method ignored
                
            } else if (directMethods.contains(methodString)) {
                System.err.println(String.format("Duplicate direct+virtual method found: %s->%s",
                        classDef.getType(), methodString));
                System.err.println("You will need to rename one of these methods, including all references.");
            }

            MethodImplementation methodImpl = method.getImplementation();
            if (methodImpl == null) {
            	
            	MethodDefinition.displayEmptyMethod(method, options);
                
            } else {
            	MethodDefinition methodDefinition=new MethodDefinition(this, method, methodImpl);
                methodDefinition.displayMethod();
            	
            }
        }
	}

	
}
