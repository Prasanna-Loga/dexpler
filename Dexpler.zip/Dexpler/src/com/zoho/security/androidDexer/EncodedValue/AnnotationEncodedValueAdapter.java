package com.zoho.security.androidDexer.EncodedValue;

import java.util.Collection;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.jf.dexlib2.iface.AnnotationElement;
import org.jf.dexlib2.iface.value.AnnotationEncodedValue;

public class AnnotationEncodedValueAdapter {
	public static void display(@Nonnull AnnotationEncodedValue annotationEncodedValue, @Nullable String containingClass){
		
		displayElementsTo(annotationEncodedValue.getElements(), containingClass);
        
	}

	public static void displayElementsTo(@Nonnull Collection<? extends AnnotationElement> annotationElements, @Nullable String containingClass){
		
		for (AnnotationElement annotationElement : annotationElements) {
			
			EncodedValueAdaptor.display(annotationElement.getValue(), containingClass);
			
		}
		
	}

}
