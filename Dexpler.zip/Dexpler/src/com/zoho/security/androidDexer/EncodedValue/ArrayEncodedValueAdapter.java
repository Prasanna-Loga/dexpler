package com.zoho.security.androidDexer.EncodedValue;

import java.util.Collection;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.jf.dexlib2.iface.value.ArrayEncodedValue;
import org.jf.dexlib2.iface.value.EncodedValue;

public class ArrayEncodedValueAdapter {

	public static void display(@Nonnull ArrayEncodedValue arrayEncodedValue, @Nullable String containingClass) {
		
		Collection<? extends EncodedValue> values = arrayEncodedValue.getValue();
		if (values.size() == 0) {
			
			return;
		}
		int size=0;

		for (EncodedValue encodedValue : values) {

			EncodedValueAdaptor.display(encodedValue, containingClass);
			size++;
			if(size!=values.size())
			System.out.print(", ");
		}
		
	}
}
