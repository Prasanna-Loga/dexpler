package com.zoho.security.androidDexer.EncodedValue;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.jf.dexlib2.ValueType;
import org.jf.dexlib2.iface.value.*;

import com.zoho.security.androidDexer.adapter.QualifiedName;

public abstract class EncodedValueAdaptor {
    public static void display(@Nonnull EncodedValue encodedValue, @Nullable String containingClass){
        switch (encodedValue.getValueType()) {
            case ValueType.ANNOTATION:
                AnnotationEncodedValueAdapter.display((AnnotationEncodedValue)encodedValue, containingClass);
                return;
            case ValueType.ARRAY:
                ArrayEncodedValueAdapter.display((ArrayEncodedValue)encodedValue, containingClass);
                return;
            case ValueType.BOOLEAN:
                System.out.print(((BooleanEncodedValue)encodedValue).getValue());
                return;
            case ValueType.BYTE:
                System.out.print(((ByteEncodedValue)encodedValue).getValue());
                return;
            case ValueType.CHAR:
                System.out.print(((CharEncodedValue)encodedValue).getValue());
                return;
            case ValueType.DOUBLE:
                System.out.print(((DoubleEncodedValue)encodedValue).getValue());
                return;
            case ValueType.ENUM:
//                EnumEncodedValue enumEncodedValue = (EnumEncodedValue)encodedValue;
//                boolean useImplicitReference = false;
//                if (enumEncodedValue.getValue().getDefiningClass().equals(containingClass)) {
//                    useImplicitReference = true;
//                }
//                writer.write(".enum ");
//                ReferenceUtil.writeFieldDescriptor(writer, enumEncodedValue.getValue(), useImplicitReference);
                return;
            case ValueType.FIELD:
//                FieldEncodedValue fieldEncodedValue = (FieldEncodedValue)encodedValue;
//                useImplicitReference = false;
//                if (fieldEncodedValue.getValue().getDefiningClass().equals(containingClass)) {
//                    useImplicitReference = true;
//                }
//                ReferenceUtil.writeFieldDescriptor(writer, fieldEncodedValue.getValue(), useImplicitReference);
                return;
            case ValueType.FLOAT:
                System.out.print(((FloatEncodedValue)encodedValue).getValue());
                return;
            case ValueType.INT:
                System.out.print(((IntEncodedValue)encodedValue).getValue());
                return;
            case ValueType.LONG:
                System.out.print(((LongEncodedValue)encodedValue).getValue());
                return;
            case ValueType.METHOD:
//                MethodEncodedValue methodEncodedValue = (MethodEncodedValue)encodedValue;
//                useImplicitReference = false;
//                if (methodEncodedValue.getValue().getDefiningClass().equals(containingClass)) {
//                    useImplicitReference = true;
//                }
//                ReferenceUtil.writeMethodDescriptor(writer, methodEncodedValue.getValue(), useImplicitReference);
                return;
            case ValueType.NULL:
                System.out.print("null");
                return;
            case ValueType.SHORT:
                System.out.print(((ShortEncodedValue)encodedValue).getValue());
                return;
            case ValueType.STRING:
                System.out.print(((StringEncodedValue)encodedValue).getValue());
                return;
            case ValueType.TYPE:
            	QualifiedName qualifiedName=new QualifiedName();
            	
            	System.out.print(qualifiedName.getQualifiedName(((TypeEncodedValue)encodedValue).getValue()));
                return;
            
            default :
            	throw new IllegalArgumentException("Unknown encoded value type: " + encodedValue.getValueType());
                
        }
    }
}