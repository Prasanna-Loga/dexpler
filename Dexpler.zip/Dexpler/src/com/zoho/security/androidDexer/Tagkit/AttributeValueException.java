package com.zoho.security.androidDexer.Tagkit;

public class AttributeValueException extends RuntimeException {

	  /**
	   * 
	   */
	  private static final long serialVersionUID = 5318900011605820606L;
	}
