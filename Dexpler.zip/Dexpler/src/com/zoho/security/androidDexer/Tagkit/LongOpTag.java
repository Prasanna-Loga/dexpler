package com.zoho.security.androidDexer.Tagkit;


public class LongOpTag implements Tag {
	  public String getName() {
	    return "LongOpTag";
	  }

	  public byte[] getValue() {
	    byte[] b = new byte[1];
	    b[0] = 0;
	    return b;
	  }

	}