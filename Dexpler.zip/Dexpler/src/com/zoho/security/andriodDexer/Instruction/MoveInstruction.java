package com.zoho.security.andriodDexer.Instruction;

import org.jf.dexlib2.iface.instruction.Instruction;
import org.jf.dexlib2.iface.instruction.TwoRegisterInstruction;

import com.zoho.security.androidDexer.adapter.MethodDefinition;

public class MoveInstruction extends DexlibAbstractInstruction {

	  public MoveInstruction(Instruction instruction, int codeAdress) {
	    super(instruction, codeAdress);
	  }

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
		TwoRegisterInstruction i = (TwoRegisterInstruction) instruction;

	    int dest = i.getRegisterA();
	    int source = i.getRegisterB();
	    
	    System.out.print("\t\t\t"+instruction.getOpcode().name+"\t");
	   
	    MethodDefinition.registerFormatter.display(dest);System.out.print("=");
	    MethodDefinition.registerFormatter.display(source);
	    
	    System.out.println();
	}
}
