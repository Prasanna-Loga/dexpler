package com.zoho.security.andriodDexer.Instruction;

import org.jf.dexlib2.Opcode;
import org.jf.dexlib2.iface.instruction.Instruction;
import org.jf.dexlib2.iface.instruction.formats.Instruction12x;
import org.jf.dexlib2.iface.instruction.formats.Instruction23x;

import com.zoho.security.androidDexer.Tagkit.DoubleOpTag;
import com.zoho.security.androidDexer.Tagkit.FloatOpTag;
import com.zoho.security.androidDexer.Tagkit.IntOpTag;
import com.zoho.security.androidDexer.Tagkit.LongOpTag;
import com.zoho.security.androidDexer.adapter.MethodDefinition;

public class Binop2addrInstruction extends TaggedInstruction {

	  public Binop2addrInstruction(Instruction instruction, int codeAdress) {
	    super(instruction, codeAdress);
	  }

	  @Override
		public void display() {
			// TODO Auto-generated method stub
			if (!(instruction instanceof Instruction12x)) {
			      throw new IllegalArgumentException("Expected Instruction12x but got: " + instruction.getClass());
			    }

			Instruction12x binOp2AddrInstr = (Instruction12x) instruction;
		    int dest = binOp2AddrInstr.getRegisterA();

			    int source1 = binOp2AddrInstr.getRegisterA();
			    int source2 = binOp2AddrInstr.getRegisterB();

			    System.out.print("\t\t\t"+instruction.getOpcode().name+"  ");
			    MethodDefinition.registerFormatter.display(dest);
			    System.out.print(" = ");
			    MethodDefinition.registerFormatter.display(source1);
			    System.out.print(getExpression());
			    MethodDefinition.registerFormatter.display(source2);
			    System.out.println();

		}

		private String getExpression() {
			// TODO Auto-generated method stub
			Opcode opcode = instruction.getOpcode();
		    switch (opcode) {
		      case ADD_LONG_2ADDR:
		        setTag(new LongOpTag());
		        return " + ";
		      case ADD_FLOAT_2ADDR:
		        setTag(new FloatOpTag());
		        return " + ";
		      case ADD_DOUBLE_2ADDR:
		        setTag(new DoubleOpTag());
		        return " + ";
		      case ADD_INT_2ADDR:
		        setTag(new IntOpTag());
		        return " + ";

		      case SUB_LONG_2ADDR:
		        setTag(new LongOpTag());
		        return " - ";
		      case SUB_FLOAT_2ADDR:
		        setTag(new FloatOpTag());
		        return " - ";
		      case SUB_DOUBLE_2ADDR:
		        setTag(new DoubleOpTag());
		        return " - ";
		      case SUB_INT_2ADDR:
		        setTag(new IntOpTag());
		        return " - ";

		      case MUL_LONG_2ADDR:
		        setTag(new LongOpTag());
		        return " * ";
		      case MUL_FLOAT_2ADDR:
		        setTag(new FloatOpTag());
		        return " * ";
		      case MUL_DOUBLE_2ADDR:
		        setTag(new DoubleOpTag());
		        return " * ";
		      case MUL_INT_2ADDR:
		        setTag(new IntOpTag());
		        return " * ";

		      case DIV_LONG_2ADDR:
		        setTag(new LongOpTag());
		        return " / ";
		      case DIV_FLOAT_2ADDR:
		        setTag(new FloatOpTag());
		        return " / ";
		      case DIV_DOUBLE_2ADDR:
		        setTag(new DoubleOpTag());
		        return " / ";
		      case DIV_INT_2ADDR:
		        setTag(new IntOpTag());
		        return " / ";

		      case REM_LONG_2ADDR:
		        setTag(new LongOpTag());
		        return " % ";
		      case REM_FLOAT_2ADDR:
		        setTag(new FloatOpTag());
		        return " % ";
		      case REM_DOUBLE_2ADDR:
		        setTag(new DoubleOpTag());
		        return " % ";
		      case REM_INT_2ADDR:
		        setTag(new IntOpTag());
		        return " % ";

		      case AND_LONG_2ADDR:
		        setTag(new LongOpTag());
		        return " & ";
		      case AND_INT_2ADDR:
		        setTag(new IntOpTag());
		        return " & ";

		      case OR_LONG_2ADDR:
		        setTag(new LongOpTag());
		        return " | ";
		      case OR_INT_2ADDR:
		        setTag(new IntOpTag());
		        return " | ";

		      case XOR_LONG_2ADDR:
		        setTag(new LongOpTag());
		        return " ^ ";
		      case XOR_INT_2ADDR:
		        setTag(new IntOpTag());
		        return " ^ ";

		      case SHL_LONG_2ADDR:
		        setTag(new LongOpTag());
		        return " << ";
		      case SHL_INT_2ADDR:
		        setTag(new IntOpTag());
		        return " << ";

		      case SHR_LONG_2ADDR:
		        setTag(new LongOpTag());
		        return " >> ";
		      case SHR_INT_2ADDR:
		        setTag(new IntOpTag());
		        return " >> ";

		      case USHR_LONG_2ADDR:
		        setTag(new LongOpTag());
		        return " >>> ";
		      case USHR_INT_2ADDR:
		        setTag(new IntOpTag());
		        return " >>> ";

		      default:
		        throw new RuntimeException("Invalid Opcode: " + opcode);
		    }
		}

	}
