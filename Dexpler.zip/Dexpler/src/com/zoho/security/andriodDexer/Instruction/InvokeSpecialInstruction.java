package com.zoho.security.andriodDexer.Instruction;

import org.jf.dexlib2.iface.instruction.Instruction;

public class InvokeSpecialInstruction extends MethodInvocationInstruction {

	  public InvokeSpecialInstruction(Instruction instruction, int codeAdress) {
	    super(instruction, codeAdress);
	  }

	@Override
	public void display() {
		// TODO Auto-generated method stub
		super.display();
	}
}
