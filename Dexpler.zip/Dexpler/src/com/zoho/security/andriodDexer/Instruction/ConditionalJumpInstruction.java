package com.zoho.security.andriodDexer.Instruction;

import org.jf.dexlib2.iface.instruction.Instruction;

import com.zoho.security.androidDexer.adapter.MethodDefinition;


public class ConditionalJumpInstruction extends JumpInstruction {

	  public ConditionalJumpInstruction(Instruction instruction, int codeAdress) {
	    super(instruction, codeAdress);
	  }

	  @Override
	public void display() {
		// TODO Auto-generated method stub
		super.display();
	}
	  
}
