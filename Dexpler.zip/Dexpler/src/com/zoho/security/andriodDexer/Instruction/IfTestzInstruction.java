package com.zoho.security.andriodDexer.Instruction;

import org.jf.dexlib2.iface.instruction.Instruction;
import org.jf.dexlib2.iface.instruction.formats.Instruction21t;

import com.zoho.security.androidDexer.adapter.MethodDefinition;

public class IfTestzInstruction extends ConditionalJumpInstruction {

	  public IfTestzInstruction(Instruction instruction, int codeAdress) {
	    super(instruction, codeAdress);
	  }

	  @Override
		public void display() {
			// TODO Auto-generated method stub
			  Instruction21t i = (Instruction21t) instruction;
			    
			  System.out.print("\t\t\t"+instruction.getOpcode().name+" ");
			  
			  MethodDefinition.registerFormatter.display(i.getRegisterA());
			  
			  super.display();
			  System.out.println(targetInstruction);
		}
}
