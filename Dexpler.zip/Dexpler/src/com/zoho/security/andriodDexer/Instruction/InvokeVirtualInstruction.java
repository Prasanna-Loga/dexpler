package com.zoho.security.andriodDexer.Instruction;

import org.jf.dexlib2.iface.instruction.Instruction;

public class InvokeVirtualInstruction extends MethodInvocationInstruction {
	public InvokeVirtualInstruction(Instruction instruction,int codeAddress) {
		// TODO Auto-generated constructor stub
		super(instruction,codeAddress);
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		super.display();
	}

	

}
