package com.zoho.security.andriodDexer.Instruction;

import org.jf.dexlib2.iface.instruction.Instruction;
import org.jf.dexlib2.iface.instruction.ReferenceInstruction;
import org.jf.dexlib2.iface.instruction.formats.Instruction11x;

public class ReturnInstruction extends DexlibAbstractInstruction {

	  public ReturnInstruction(Instruction instruction, int codeAdress) {
	    super(instruction, codeAdress);
	  }
	  
	  public void display() {
		// TODO Auto-generated method stub
		  //System.out.print(((ReferenceInstruction) instruction).getReference()+"***********************************");

		  System.out.print("\t\t\t"+instruction.getOpcode().name+"\t");
		  
		  Instruction11x returnInstruction = (Instruction11x) this.instruction;
		  System.out.println("\tv"+returnInstruction.getRegisterA());
		  
	}

}
