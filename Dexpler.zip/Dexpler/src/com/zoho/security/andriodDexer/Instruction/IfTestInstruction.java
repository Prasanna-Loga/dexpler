package com.zoho.security.andriodDexer.Instruction;

import org.jf.dexlib2.iface.instruction.Instruction;
import org.jf.dexlib2.iface.instruction.formats.Instruction22t;

import com.zoho.security.androidDexer.adapter.MethodDefinition;


public class IfTestInstruction extends ConditionalJumpInstruction {

	  public IfTestInstruction(Instruction instruction, int codeAdress) {
	    super(instruction, codeAdress);
	  }
	  
	  @Override
	public void display() {
		// TODO Auto-generated method stub
		  Instruction22t i = (Instruction22t) instruction;
		    
		  System.out.print("\t\t\t"+instruction.getOpcode().name+" ");
		  
		  MethodDefinition.registerFormatter.display(i.getRegisterA());
		  System.out.print(",");
		  MethodDefinition.registerFormatter.display(i.getRegisterB());
		  
		  super.display();
		  System.out.println(targetInstruction);
	}
}
