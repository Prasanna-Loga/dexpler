package com.zoho.security.andriodDexer.Instruction;

import org.jf.dexlib2.iface.instruction.Instruction;
import org.jf.dexlib2.iface.instruction.formats.Instruction21c;

import com.zoho.security.androidDexer.adapter.MethodDefinition;
import com.zoho.security.androidDexer.adapter.QualifiedName;

public class CheckCastInstruction extends DexlibAbstractInstruction {

	  public CheckCastInstruction(Instruction instruction, int codeAdress) {
	    super(instruction, codeAdress);
	  }

	@Override
	public void display() {
		// TODO Auto-generated method stub
		QualifiedName qualifiedName=new QualifiedName();
		
		if (!(instruction instanceof Instruction21c)) {
		      throw new IllegalArgumentException("Expected Instruction21c but got: " + instruction.getClass());
		    }

		    Instruction21c checkCastInstr = (Instruction21c) instruction;

		    System.out.print("\t\t\t"+instruction.getOpcode().name+" ");
		    MethodDefinition.registerFormatter.display(checkCastInstr.getRegisterA());
		    System.out.println(" "+qualifiedName.getQualifiedName((checkCastInstr.getReference()).toString()));
	}
}
