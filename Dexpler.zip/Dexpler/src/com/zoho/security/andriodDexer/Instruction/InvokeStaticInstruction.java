package com.zoho.security.andriodDexer.Instruction;

import org.jf.dexlib2.iface.instruction.Instruction;


public class InvokeStaticInstruction extends MethodInvocationInstruction {

	  public InvokeStaticInstruction(Instruction instruction, int codeAddress) {
	    super(instruction, codeAddress);
	  }

	@Override
	public void display() {
		// TODO Auto-generated method stub
		super.display();
	}

}
