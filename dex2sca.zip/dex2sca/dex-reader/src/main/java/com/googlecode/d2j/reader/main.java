package com.googlecode.d2j.reader;

import java.io.File;
import java.io.IOException;

import com.googlecode.d2j.dex.writer.DexFileWriter;

public class main {
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		long startTime = System.currentTimeMillis();

		File dexFile = new File("/home/local/ZOHOCORP/prasanna-8769/Downloads/app-debug/classes2.dex");
		
		DexFileWriter w = new DexFileWriter();
        DexFileReader dexFileReader = new DexFileReader(dexFile);
        dexFileReader.accept(w);
        w.toByteArray();
		
        
		
		Runtime runtime = Runtime.getRuntime();
		// Run the garbage collector
		runtime.gc();
		// Calculate the used memory
		long memory = runtime.totalMemory() - runtime.freeMemory();
		System.out.println("Used memory is bytes: " + memory / (1024L * 1024L) + "mb");

		 

		long stopTime = System.currentTimeMillis();
		long elapsedTime = stopTime - startTime;
		System.out.println("Time: " + elapsedTime + "ms");
		
		

	}

}
